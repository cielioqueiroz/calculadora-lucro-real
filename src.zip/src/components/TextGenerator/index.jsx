export const TextGenerator = () => {
  return (
    <p
      style={{
        fontSize: "1rem",
        textAlign: "center",
        color: "#0D253D",
        fontFamily: "roboto",
        fontWeight: "bold",
        margin: "50px 0",
      }}
    >
      Torne mais acessível a análise financeira de sua empresa ao simplificar o
      cálculo do Lucro Real.
    </p>
  );
};
